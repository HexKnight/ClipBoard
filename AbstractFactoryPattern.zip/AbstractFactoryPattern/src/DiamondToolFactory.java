
public class DiamondToolFactory extends ToolFactory{
	@Override
	public Tool makeTool(String type, boolean enchanted, String name) {
		
		if (enchanted) {
			if (type.equals("sword"))
				return new EnchantedDiamondSword(name);
			else if (type.equals("pickaxe"))
				return new EnchantedDiamondPickaxe(name);
			else if (type.equals("axe"))
				return new EnchantedDiamondAxe(name);
			else
				return null;
		} else {
			if (type.equals("sword"))
				return new DiamondSword(name);
			else if (type.equals("pickaxe"))
				return new DiamondPickaxe(name);
			else if (type.equals("axe"))
				return new DiamondAxe(name);
			else
				return null;
		}
		
		
	}

}
