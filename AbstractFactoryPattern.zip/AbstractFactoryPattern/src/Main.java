
public class Main {

	public static void main(String[] args) {
		
		ToolFactory overBlackSmith = ToolSuperFactory.makeToolFactory("diamond");
		ToolFactory netherBlackSmith = ToolSuperFactory.makeToolFactory("netherite");
		
		doStuff(overBlackSmith.makeTool("pickaxe", true, "The Pick"));
		doStuff(netherBlackSmith.makeTool("sword", false, "Vanisher"));
		doStuff(netherBlackSmith.makeTool("axe", false, "Boi Axe"));
		doStuff(netherBlackSmith.makeTool("pickaxe", true, "True Boi Pick"));
		
	}

	
	public static void doStuff(Tool tool) {
		System.out.println(tool.toString());
		tool.show();
		tool.use();
		System.out.println();
	}
}
