
public class NetheriteToolFactory extends ToolFactory{
	@Override
	public Tool makeTool(String type, boolean enchanted, String name) {
		
		if (enchanted) {
			if (type.equals("sword"))
				return new EnchantedNetheriteSword(name);
			else if (type.equals("pickaxe"))
				return new EnchantedNetheritePickaxe(name);
			else if (type.equals("axe"))
				return new EnchantedNetheriteAxe(name);
			else
				return null;
		} else {
			if (type.equals("sword"))
				return new NetheriteSword(name);
			else if (type.equals("pickaxe"))
				return new NetheritePickaxe(name);
			else if (type.equals("axe"))
				return new NetheriteAxe(name);
			else
				return null;
		}
		
	}
}
