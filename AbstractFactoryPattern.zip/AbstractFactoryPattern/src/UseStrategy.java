
public interface UseStrategy {
	public void use();
}

class Stab implements UseStrategy {
	@Override
	public void use() {
		System.out.println("Stabbing with the sword..");
	}
}

class Dig implements UseStrategy {
	@Override
	public void use() {
		System.out.println("Digging with the pickaxe..");
	}
}

class Cut implements UseStrategy {
	@Override
	public void use() {
		System.out.println("Cutting with the axe..");
	}
}