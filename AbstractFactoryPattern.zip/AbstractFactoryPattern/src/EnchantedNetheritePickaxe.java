
public class EnchantedNetheritePickaxe extends Tool{
	
	public EnchantedNetheritePickaxe(String name) {
		super("Enchanted Netherite Pickaxe", 8, new Dig(), name);
	}

	@Override
	public void show() {
		System.out.println("  *+*\n */|*\n*<{o}=======[]*\n *\\|*\n  *+*");
	}
	
}
