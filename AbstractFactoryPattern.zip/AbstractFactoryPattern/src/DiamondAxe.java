
public class DiamondAxe extends Tool{
	
	public DiamondAxe(String name) {
		super("Diamond Axe", 3, new Cut(), name);
	}

	@Override
	public void show() {
		System.out.println("[::]========0\n/||\\\n----");
	}
	
}
