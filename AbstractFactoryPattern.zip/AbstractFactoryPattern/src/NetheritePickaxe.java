
public class NetheritePickaxe extends Tool{
	
	public NetheritePickaxe(String name) {
		super("Netherite Pickaxe", 7, new Dig(), name);
	}

	@Override
	public void show() {
		System.out.println("  +\n /|\n<{o}=======[]\n \\|\n  +");
	}
	
}
