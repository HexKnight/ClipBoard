
public class EnchantedDiamondSword extends Tool{
	
	public EnchantedDiamondSword(String name) {
		super("Enchanted Diamond Sword", 8, new Stab(), name);
	}

	@Override
	public void show() {
		System.out.println("*<########[]--0*");
	}
	
}
