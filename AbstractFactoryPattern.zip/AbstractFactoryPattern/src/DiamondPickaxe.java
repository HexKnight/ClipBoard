
public class DiamondPickaxe extends Tool{
	
	public DiamondPickaxe(String name) {
		super("Diamond Pickaxe", 5, new Dig(), name);
	}

	@Override
	public void show() {
		System.out.println(" /|\n<||========0\n \\|");
	}
	
}
