
public class EnchantedDiamondPickaxe extends Tool{
	
	public EnchantedDiamondPickaxe(String name) {
		super("Enchanted Diamond Pickaxe", 6, new Cut(), name);
	}

	@Override
	public void show() {
		System.out.println(" */|*\n*<||========0*\n *\\|*");
	}
	
}
