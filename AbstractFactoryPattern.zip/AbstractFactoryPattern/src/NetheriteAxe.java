
public class NetheriteAxe extends Tool{
	
	public NetheriteAxe(String name) {
		super("Netherite Axe", 5, new Cut(), name);
	}

	@Override
	public void show() {
		System.out.println(" [##]========{}\n /||\\\n<---->");
	}
	
}
