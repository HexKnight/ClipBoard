
public class EnchantedDiamondAxe extends Tool{
	
	public EnchantedDiamondAxe(String name) {
		super("Enchanted Diamond Axe", 4, new Cut(), name);
	}

	@Override
	public void show() {
		System.out.println("*[::]========0*\n*/||\\*\n*----*");
	}
	
}
