
public class DiamondSword extends Tool{
	
	public DiamondSword(String name) {
		super("Diamond Sword", 7, new Stab(), name);
	}

	@Override
	public void show() {
		System.out.println("<########[]--0");
	}
	
}
