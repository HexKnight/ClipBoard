
public class EnchantedNetheriteAxe extends Tool{
	
	public EnchantedNetheriteAxe(String name) {
		super("Enchanted Netherite Axe", 6, new Cut(), name);
	}

	@Override
	public void show() {
		System.out.println(" *[##]========{}*\n */||\\*\n*<---->*");
	}
	
}
