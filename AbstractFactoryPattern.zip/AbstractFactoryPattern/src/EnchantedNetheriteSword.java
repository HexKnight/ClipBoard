
public class EnchantedNetheriteSword extends Tool{
	
	public EnchantedNetheriteSword(String name) {
		super("Enchanted Netherite Sword", 10, new Stab(), name);
	}

	@Override
	public void show() {
		System.out.println("*<;;;;;;;;[]==0*");
	}
	
}
