
public interface ToolSuperFactory {
	public static ToolFactory makeToolFactory(String type) {
		
		if (type.equals("diamond"))
			return new DiamondToolFactory();
		else if (type.equals("netherite"))
			return new NetheriteToolFactory();
		else
			return null;
		
	}
}
