
public abstract class ToolFactory {
	public abstract Tool makeTool(String type, boolean enchanted, String name);
}
