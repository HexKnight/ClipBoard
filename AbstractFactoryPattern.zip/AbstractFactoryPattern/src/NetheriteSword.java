
public class NetheriteSword extends Tool{
	
	public NetheriteSword(String name) {
		super("Netherite Sword", 9, new Stab(), name);
	}

	@Override
	public void show() {
		System.out.println("<;;;;;;;;[]==0");
	}
	
}
