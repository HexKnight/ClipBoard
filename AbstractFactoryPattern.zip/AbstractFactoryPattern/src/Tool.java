
public abstract class Tool {
	
	private final String type;
	private final int speed;
	private final UseStrategy strat;
	private String name;
	
	protected Tool(String type, int speed, UseStrategy strat, String name) {
		this.type = type;
		this.speed = speed;
		this.strat = strat;
		this.name = name;
	}
	
	public abstract void show();
	
	public final String toString() {
		return "Name: " + this.name +
			   "\ntype: " + this.type +
			   "\nSpeed: " + this.speed;
	}
	
	public void use() {
		this.strat.use();
	}

	public final void setName(String val) { this.name = val; }
	public final String getName() { return this.name; }
	
	public final String getType() { return this.type; }
	
	public final int getSpeed() { return this.speed; }
	
}
